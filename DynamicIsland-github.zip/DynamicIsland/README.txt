1) Android Studio'da File > Open ile bu klasoru ac, Gradle sync bitsin.
2) Build > Build APK(s)  (veya telefonu USB ile bagla, Run).
3) APK: app/build/outputs/apk/
4) Telefonda uygulamayi ac: once izin ver, sonra "Adayi baslat".
